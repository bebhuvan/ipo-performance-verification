# Corporate-Actions Pipeline (abstracted, whole-market)

This is the abstracted logic of how the site builds its corporate-actions dataset, generalised
to **all NSE + BSE corporate actions**, not the MTF-funded subset. The live builder
(`tools/build_corp_calendar.py`) applies one extra filter at the end (keep only stocks that carry
an MTF book); everything before that filter is exactly what is described here. To target every
listed stock, drop that final filter (see [Scoping](#8-scoping-mtf-subset-vs-whole-market)).

The design goal: **one clean, deduped, classified stream of corporate actions per stock**, keyed
by ISIN, resilient to any single source being unavailable, and carrying the human-meaningful
detail (dividend per share, split/bonus/rights ratio) for each event.

```
  SOURCES ----> FETCH ----> PARSE ----> CLASSIFY ----> NORMALISE ----> MERGE+DEDUP ----> ENRICH ----> OUTPUT
 (3 feeds)    (resilient)  (per feed)  (7 types)     (dates/ratios)  (ISIN,ex,type)   (name/mcap)  (one row/event)
```

---

## 1. Sources

Three independent feeds, each with a distinct strength. They are merged; none is trusted alone.

| Source | What it is | Coverage | Role | Resilience |
|---|---|---|---|---|
| **NSE PR bhavcopy `bc` file** | The `bc<ddmmyyyy>.csv` member inside the daily `PR<ddmmyy>.zip` on `nsearchives`. Columns: `SERIES,SYMBOL,SECURITY,RECORD_DT,BC_STRT_DT,BC_END_DT,EX_DT,ND_STRT_DT,ND_END_DT,PURPOSE`. | ~10 years of daily files. PAST + effective ex-dates. Full split/bonus/rights text. | **PRIMARY.** Static archive file, far harder to gate than a JSON API. Accumulated into an append-only archive. | Very high (static CDN files). |
| **NSE `corporates-corporateActions` JSON API** | `/api/corporates-corporateActions?index=equities&from_date=..&to_date=..`. Whole-market for a date window, including **future announced** ex-dates. | A rolling window (serves ~2 yrs/request). | **BACKUP + forward-looking.** Supplies UPCOMING ex-dates the daily `bc` files do not carry yet, and fills any recent gap. When it is gated, the archive stands alone. | Medium (JSON API, rate-limited). |
| **BSE `CORPACT_*.TXT`** | A pipe-delimited member inside the always-latest `scrip.zip` (`bseindia.com/downloads/Help/file/scrip.zip`). Whole-market, full history. | Whole market, many years. | Covers **BSE-primary** names the NSE feeds never carry, and cross-checks dual-listed ones. | High (one static zip). |

Two identity helpers ride alongside:

- **BSE scrip master** (`BSE_EQ_SCRIP` inside the same `scrip.zip`, or the `ListofScripData` API):
  maps `scrip_code -> (ISIN, trading symbol, par value)`. CORPACT keys rows by scrip code, so this
  is required to reach an ISIN and to convert a "% of face value" dividend into rupees-per-share.
- **NSE symbol -> ISIN** (from the daily security master, or the corp-action API rows which already
  carry ISIN). Needed because the PR `bc` file is symbol-keyed, not ISIN-keyed.

---

## 2. Fetch strategy

Each source has a different retrieval shape; all fetches **fail open** (a miss keeps the last good
data, never aborts the build).

### 2a. NSE PR archive (append-only)
The `bc` file is one day at a time, so history is accumulated into a committed archive
(`nse_pr_corpact.json`) rather than re-downloaded each run:

```
load archive (or empty)
seen := { (ex, symbol, type) already stored }
start := last_fetch - OVERLAP_DAYS   (re-scan a few recent days for late/restated rows)
         or today - BACKFILL_DAYS    (first run)
for each WEEKDAY d in [start .. today]:        # skip Sat/Sun outright (markets never trade)
    lines := bc file for d, else skip           # a holiday 404 is normal, single attempt
    for each row:
        keep only equity-ish SERIES (EQ/BE/BZ/B1/B2/SM/ST/…); drop NCD/debt interest rows
        ex := normalise(EX_DT) or normalise(RECORD_DT)
        type, detail := classify(PURPOSE)
        if type == "other": skip                # interest / redemption / AGM etc.
        if (ex, symbol, type) new: append {ex, symbol, series, type, detail, purpose}
last_fetch := max(last_fetch, end)              # never regress on an explicit older backfill
```

Rate-limit handling (a decade of daily files trips NSE's limiter): fetch in **modest concurrent
batches with a pause between them**; on a batch that comes back mostly `403`, back off, re-warm a
fresh session, and retry the same batch; give up gracefully after a few blocked batches, keeping
the partial archive. An explicit `--from/--until` range backfills older history without touching
`last_fetch`.

> Deep history note: the NSE **reports API** (`/api/reports` with the archive descriptor for a
> given monthly report) can serve archive files that the direct static URL no longer hosts, and
> can fill holes in the static archive. Same fetch-then-parse shape; use it as a deep/gap-filling
> fallback behind the fast static URL.

### 2b. NSE corp-action JSON API (windowed)
One request for the whole `[today - BACK, today + FWD]` window. Parse the JSON rows directly.
Because it carries **future** ex-dates, it is the only source for the "upcoming" side.

### 2c. BSE CORPACT (whole file)
Download `scrip.zip` once, read the `CORPACT_*.TXT` and `BSE_EQ_SCRIP` members, build the
`scrip_code -> (ISIN, symbol, par)` map, then walk every CORPACT row.

---

## 3. Classification (the type taxonomy)

Every raw action collapses to one of seven **types**, plus a `qtychange` flag:

| type | meaning | `qtychange` | detail example |
|---|---|---|---|
| `dividend` | cash distribution | false | `₹2.50/sh`, `Interim ₹1/sh`, `Special ₹5/sh` |
| `bonus` | free shares in a ratio | **true** | `1:1`, `4:1` |
| `split` | face-value sub-division | **true** | `₹10 → ₹2`, `to ₹2 FV` |
| `rights` | discounted subscription | false | `3:8` |
| `demerger` | spin-off / scheme of arrangement | false | (text) |
| `buyback` | share buyback | false | (text) |
| `other` | everything else (AGM, NCD interest, redemption…) | false | dropped downstream |

`qtychange == true` means the ex-date **re-bases the share count** (a price chart must back-adjust
through it; a holdings/margin figure changes). Dividends and rights are informational.

The classifier is **source-specific text/code decoding into the same taxonomy**:

**NSE text** (`bc` PURPOSE and API subject share one decoder):
```
lower := text.lower()
if any("split","sub-div","sub division","face value" in lower):
        detail := "₹{X} → ₹{Y}" from "from Rs X ... to Rs Y";           type=split, qty=true
elif match bonus \b[^\d]*(\d+)\s*:\s*(\d+):  detail := "{n}:{m}";       type=bonus,  qty=true
elif rights present:  detail := "{n}:{m}" from "RIGHTS n:m", else "";   type=rights
elif demerger/spin/scheme of arrangement:                              type=demerger
elif "buy" and "back":                                                 type=buyback
elif dividend present (\bdividend\b | \bdiv\b | intdiv | spdiv | …):
        amount := ₹ after "Rs"/"Re"; prefix "Interim "/"Special ";     type=dividend
else:                                                                  type=other
```
Split checks run BEFORE dividend so "sub-division" cannot be mistaken for "div". The `bc` file
abbreviates dividends (`DIV - RS 2 PER SH`, `INTDIV`, `DIVSPDIV`, `RE` for a singular rupee) while
the API spells them out (`Dividend - Rs 3.50 Per Share`); one regex covers both. Rights ratios are
extracted the same way from `RIGHTS 3:8`.

**BSE codes** (CORPACT PURPOSE is cryptic, decode by code):
```
BN-<nnnn><nnnn>  -> bonus,  ratio = int(first4):int(last4)            (e.g. BN-00040001 = 4:1)
SS / SUB-DIV     -> split,  detail = "₹X → ₹Y" if present else "to ₹{par} FV"
RIGHT            -> rights
DP / IPD - <n>%  -> dividend, ₹/share = (n% ) × par                  (Interim if IPD/IID)
else             -> other (AGM, BGM, bond interest, listing fee, …)  -> dropped
```

> **BSE quirks:**
> - **Par value is in paise** in `BSE_EQ_SCRIP` (RELIANCE 1000 = ₹10, TCS 100 = ₹1). Divide by 100
>   to rupees before `₹/share = pct% × par`, or a "DP-450%" reads as "₹450/sh" instead of ₹4.5.
> - **BSE has no split ratio.** A split is a bare `SS`; the face-value change lives on the NSE side,
>   so NSE wins the dedup and supplies "₹10 → ₹2". For a BSE-only split, fall back to the post-split
>   face value ("to ₹2 FV").
> - A symbol has **one row per series** (EQ, BE, T, …). Only the relevant series row matters;
>   dedup by ISIN keeps the right one.

---

## 4. Normalisation

Everything is coerced to a stable shape before merge, or dedup silently breaks:

- **Ex-date -> `YYYY-MM-DD`.** The `bc` `EX_DT` format CHANGED across years: recent files are ISO
  `YYYY-MM-DD`, older ones (pre ~2019) are `DD/MM/YYYY` (and some `DD-Mon-YYYY`). Normalise all
  three. BSE CORPACT ex-dates are already ISO.
- **Ratios -> `n:m`** strings (bonus/rights). Face-value change -> `₹X → ₹Y`.
- **Dividend -> `₹A/sh`** with an `Interim `/`Special ` prefix when applicable; BSE's "% of FV" is
  converted via par value.
- **Identity:** join to a canonical **ISIN** (NSE via symbol->ISIN master; BSE via scrip->ISIN
  master). Display symbol and company name resolved alongside.

---

## 5. Merge and dedup

All sources are unioned and deduped on the key **`(ISIN, ex-date, type)`**. A dual-listed dividend
appears in the NSE feeds AND BSE CORPACT with the same key and collapses to one row.

**Source priority = order of insertion (first to claim a key wins its detail):**

```
1. NSE PR archive      (PRIMARY: static, resilient; carries split/bonus/rights ratios)
2. NSE JSON API        (BACKUP:  adds FUTURE ex-dates + any recent gap; if gated, adds nothing)
3. BSE CORPACT         (adds BSE-primary names; cross-checks dual-listed, which dedup away)

seen := {}
actions := []
for src in [archive, api, bse]:        # priority order
    for a in src.actions():
        k := (a.isin, a.ex, a.type)
        if k in seen: continue          # earlier (higher-priority) source keeps its detail
        seen.add(k); actions.append(a)
if not actions: raise                   # every source empty = real failure, do not write blank
sort actions by ex-date
```

Why this order: the archive is the most reliable and carries clean ratios, so it wins the detail;
the API is essential only for the **upcoming** side (the daily `bc` files do not list an ex-date
until it is near), so it fills forward; BSE is essential only for **BSE-primary** names.

**Notable dedup subtlety: ISIN changes on split/bonus.** A face-value split gives the stock a NEW
ISIN (e.g. `INE...11 -> INE...29`). The NSE feeds record the event under the PRE-action ISIN; if
you are joining to a current-ISIN universe, that NSE row will not match and drops out, while BSE
(keyed on the current ISIN) still carries it. This is a real reason BSE contributes events that
look "NSE-missing." When targeting all actions by their own (pre-action) ISIN, keep both.

---

## 6. Enrichment

After the deduped stream exists, attach per-stock context (all joins by ISIN, then symbol):

- **Company name** and **trading symbol** (from the identity masters).
- **Total / free-float market cap** (from a market-cap snapshot), so each event can show the size
  of the affected company.
- Any other per-stock overlays (sector, surveillance status, etc.) join the same way.

Enrichment is a left-join: an event with no match still emits, with the missing fields blank.

---

## 7. Output schema

One row per `(ISIN, ex-date, type)` event:

```json
{
  "generated": "YYYY-MM-DD",
  "window":  { "from": "YYYY-MM-DD", "to": "YYYY-MM-DD" },
  "count": 12345,
  "count_by_source": { "archive": ..., "api_added": ..., "bse_added": ... },
  "actions": [
    {
      "ex": "YYYY-MM-DD",
      "symbol": "RELIANCE",
      "name": "Reliance Industries Ltd",
      "isin": "INE002A01018",
      "type": "dividend|bonus|split|rights|demerger|buyback|other",
      "detail": "₹5/sh | 1:1 | ₹10 → ₹2 | 3:8 | …",
      "qtychange": false,
      "total_mcap_cr": 1789000,      // enrichment (optional)
      "free_float_mcap_cr": 890000   // enrichment (optional)
    }
  ]
}
```

Split the stream into **upcoming** (`ex >= today`) and **passed** (`ex < today`) at render time;
the passed side is deep (years of history), the upcoming side is small (only announced ex-dates).

---

## 8. Scoping: MTF subset vs whole-market

The ONLY thing that makes the live builder MTF-specific is a single filter applied per source
before an action is kept:

```
funded := { ISINs that currently carry an MTF book }   # from the pipeline's screener output
... keep an action only if a.isin in funded ...
```

**To target all corporate actions, remove that membership test.** Everything else, the three
sources, the classifier, the normaliser, the dedup, the enrichment, is universe-agnostic and
already whole-market. Consequences of dropping the filter:

- Volume grows from the funded subset (a few thousand/yr) to the whole market (tens of
  thousands/yr). The append-only archive and the BSE CORPACT file are already whole-market, so no
  new fetching is needed, only the filter is lifted.
- Enrichment fields (MTF book, funded flag) become optional annotations rather than a gate.
- The `book_cr` field (MTF book at ex) is replaced or supplemented by generic size fields
  (market cap), since "book" is an MTF concept.

---

## 9. Failure modes and guarantees

- **Fail open per source.** A blocked NSE API, a missing PR day, or an unreadable BSE zip each
  degrade coverage but never abort; the last good archive/data is kept. A build only raises if
  **every** source yields nothing (guards against writing a blank file).
- **Idempotent + incremental.** The PR archive is append-only keyed by `(ex, symbol, type)`;
  re-running only adds new rows. The overlap re-scan catches late-published / restated actions.
- **Deterministic given inputs.** Classification and dedup are pure functions of the fetched text;
  only the network fetch is nondeterministic.
- **Auditable detail.** Each action keeps enough to reconstruct the human meaning (ratio, ₹/share,
  face-value change); the raw source PURPOSE can be retained for provenance.

---

## 10. Minimal build recipe (whole-market)

```
1. Refresh the NSE PR archive:   incremental fetch of new trading days (+ overlap) -> append.
2. Fetch the NSE corp-action API for [today-BACK, today+FWD]  (for upcoming ex-dates).
3. Download BSE scrip.zip once:  read CORPACT + BSE_EQ_SCRIP (scrip->ISIN, par).
4. Classify + normalise every row from all three into the 7-type taxonomy.
5. Merge in priority order (archive -> api -> bse), dedup by (ISIN, ex-date, type).
6. Enrich each event by ISIN (name, market cap, …).
7. Emit one row per event; split upcoming vs passed at render time.
   (For the MTF view only: filter step 5 to funded ISINs.)
```
