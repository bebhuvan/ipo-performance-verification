# Corporate-action price adjustment — data + method

This accompanies the two data files:

- **`corp_actions.json`** — the exact file the site ships (`mtf_dashboard_v4/corp_actions.json`), as-is.
- **`corp_actions.csv`** — the same events flattened to one row each, for spreadsheets.

The canonical in-repo documentation of this feature lives in **`PROJECT_REFERENCE.md`**
(section: "EOD close is raw/unadjusted in the data, but the /stock chart CORP-ACTION-ADJUSTS
it via an AUTHORITATIVE NSE split/bonus calendar"). The builder is `tools/build_corp_actions.py`.
NOTE: `docs/CORP_ACTIONS_PIPELINE.md` is a **different** feature — the forward-looking whole-market
*calendar* (`build_corp_calendar.py`) shown on /leveraged — not this price adjustment.

---

## What the adjustment does

The stored EOD close (`eod_close_*.json.gz`, raw cash-bhavcopy `ClsPric`) is **never modified** —
it is the true traded price, so it cliffs on split/bonus ex-dates (NESTLEIND −90% on its 1:10
split, RELIANCE −50% on a 1:1 bonus, etc.). Only the **/stock chart line** is made continuous, at
render time, by back-adjusting older closes:

> A raw close dated `t` is multiplied by the **product of the `ratio` of every action whose ex-date
> is after `t`**. The most recent segment is unchanged (factor 1.0); each earlier split/bonus scales
> the segment before it down to today's share basis.

Frontend: fetched once in the async `showCrossExchangeChart`, applied in `_adjustCorpActions`
inside the sync `displayCrossExchangeChart`. Raw data is untouched.

### `ratio` = a price multiplier (≤1 for split/bonus, >1 for a reverse split)

| Action | Text example | `ratio` | Effect on price |
|---|---|---|---|
| Face-value split | `From Rs10 To Re1` (1:10) | `new/old` = **0.1** | ×0.1 |
| Face-value split | `From Rs10 To Rs2` (1:5) | **0.2** | ×0.2 |
| Bonus a:b | `Bonus 1:1` | `b/(a+b)` = **0.5** | ×0.5 |
| Bonus a:b | `Bonus 1:2` | **0.6667** | ×0.6667 |
| Consolidation | `From Re1 To Rs10` | **10.0** | ×10 |
| Same-day split + bonus | both on one ex-date | ratios **multiplied** | product |

### Why an authoritative calendar, not a "big overnight move" heuristic

F&O stocks have **no price band**, so a genuine >40% overnight move is real (ADANIENT −28%
Hindenburg, YESBANK −56%, PAYTM −20%). A cliff heuristic would wrongly flatten those crashes. This
calendar only touches dates it actually lists, so real moves survive and only true splits/bonuses
are removed. Rights issues, demergers and ratio-less consolidations are deliberately **omitted**
(their adjustment needs a price the feed doesn't give).

---

## Sources (all in `build_corp_actions.py`, fail-open, incremental with weekly `--full`)

1. **NSE `corporates-corporateActions` BULK feed** (2017→now, ~90-day chunks) — primary; complete
   (carries NESTLE's split that BSE's CORPACT misses).
2. **BSE per-scrip `DefaultData` feed** — fills **BSE-exclusive** stocks (a BSE row but no NSE row;
   their chart uses BSE closes) that the NSE-symbol calendar can't key. NSE wins for dual-listed.
3. **BSE `CORPACT` gap-fill** — a dual-listed stock whose split/bonus predates its NSE listing is in
   neither of the above, yet its NSE close series spans the cliff (VIRINCHI, MUFIN, GYFTR…). Filled
   from CORPACT's `BN-AAAABBBB` code, else a targeted DefaultData lookup.

Runs on every deploy; a past split never changes, so history is carried forward and only the recent
window is re-fetched.

---

## `corp_actions.json` schema (as shipped)

```jsonc
{
  "_mode": "incremental" | "full",
  "_source": "…provenance sentence…",
  "bse_exclusive": <int>,      // BSE-exclusive symbols filled this build
  "corpact_filled": <int>,     // dual-listed gap dates filled
  "_generated": "YYYY-MM-DD",
  "chunks": <int>,             // NSE ~90-day windows queried
  "count":  <int>,             // symbols with >=1 action
  "events": <int>,             // total split/bonus events
  "actions": {
    "NESTLEIND": [
      { "ex": "2024-01-05", "ratio": 0.1, "subject": "Face Value Split (Sub-Division) - From Rs10/- Per Share To Re 1/- Per Share" },
      { "ex": "2025-08-08", "ratio": 0.5, "subject": "Bonus 1:1" }
    ],
    "…": [ … ]
  }
}
```

Per action: `ex` = ex-date (`YYYY-MM-DD`), `ratio` = price multiplier (above), `subject` = the raw
feed text the ratio was parsed from. Events per symbol are sorted ascending by ex-date.

## `corp_actions.csv` columns (derived, one row per event)

| column | meaning |
|---|---|
| `symbol` | NSE (or BSE-exclusive) trading symbol |
| `ex_date` | ex-date, `YYYY-MM-DD` |
| `kind` | `split` / `bonus` / `consolidation` (classified from `subject`) |
| `ratio` | price multiplier for THIS event (as above) |
| `raw_cliff_pct` | `(ratio − 1) × 100` — the raw one-day cliff on the ex-date (e.g. −90 for a 1:10 split) |
| `cumulative_adj_factor_before_ex` | product of this event's `ratio` and every LATER event's ratio for the symbol = the multiplier applied to any raw close dated **before** this ex-date |
| `subject` | raw feed text |

Worked example (NESTLEIND): a close from **before 2024-01-05** is multiplied by
`0.1 × 0.5 = 0.05`; a close **between** the split and the 2025-08-08 bonus by `0.5`; a close after
the bonus by `1.0` (unchanged).

---

## This snapshot

Generated `_generated` in the JSON. Latest build in this export: **916 symbols / 1,196 split+bonus
events**, spanning ex-dates from 2000 to 2026 (the adjustment matters from 2017-on, the site's data
window; older rows are carried in the calendar for completeness).
