#!/usr/bin/env python3
"""Build corp_actions.json · the AUTHORITATIVE split / bonus calendar per stock, so the
/stock EOD-close chart can back-adjust the raw bhavcopy close and stay continuous through
corporate actions (NESTLEIND's raw close cliffs −90% on its 1:10 split, etc.).

Source: NSE's `corporates-corporateActions` BULK feed (no symbol, a date window) · one
query returns the whole market's actions for that window, WITH the exact ratio in plain
text ("From Rs10 To Re1", "Bonus 1:1"). We chunk 2017→today in ~90-day windows (a few
dozen small queries) and parse the ratio. This is authoritative (so a real >±40% move on
an F&O stock · which HAS no price band · is left ALONE because it isn't in the calendar)
and complete (unlike BSE's CORPACT feed, which misses e.g. NESTLE's split and often omits
the ratio). Deterministic apart from the NSE fetch; fails open (keeps the committed file).

Output: `{actions: {SYMBOL: [{ex:"YYYY-MM-DD", ratio:<price multiplier ≤1 for split/bonus,
>1 for consolidation>, subject:"…"}, …]}}`. The frontend multiplies older closes by the
product of the ratios of every action AFTER that date (back-adjust; latest unchanged).
"""
import argparse
import datetime
import io
import json
import os
import re
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
V4 = os.path.join(ROOT, "mtf_dashboard_v4")
DEFAULT_OUT = os.path.join(V4, "corp_actions.json")

sys.path.insert(0, os.path.join(ROOT, "tools"))
import fetch_surveillance as FS  # noqa: E402  (reuse its strict-UA NSE session)

_BSE_API = None


def _bse_api_session(fallback=None):
    """Cached, dedicated Chrome-impersonated BSE session for the api.bseindia.com
    DefaultData calls. api.bseindia.com is Akamai-gated on datacenter (CI) IPs, so
    the mixed FS NSE/BSE session 403s; a warm_session with the full Chrome header
    set + cookie warm-up passes. Falls back to the given session on warm-up fail.
    See bse_session.py."""
    global _BSE_API
    if _BSE_API is None:
        sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
        import bse_session
        _BSE_API = bse_session.warm_session() or fallback
    return _BSE_API or fallback

START = datetime.date(2017, 1, 1)
CHUNK_DAYS = 90
# Incremental runs only re-fetch the last INCREMENTAL_DAYS of ex-dates and carry the
# older (immutable) history forward from the committed file; a --full run re-fetches
# all of 2017->today. 200d comfortably covers a normal daily gap plus any late-filed
# action, and the weekly --full backstop catches anything filed with an older ex-date.
INCREMENTAL_DAYS = 200


def _load_prior_actions():
    """The committed corp_actions.json's `actions` map, for the incremental carry-forward."""
    for cand in (DEFAULT_OUT, os.path.join(ROOT, "compressed_data", "corp_actions.json")):
        if os.path.exists(cand):
            try:
                return (json.load(open(cand, encoding="utf-8")) or {}).get("actions") or {}
            except Exception:
                pass
    return {}


def _carry_forward(fresh, prior):
    """Overlay a freshly-fetched (recent-window) `actions` list-map onto the committed
    `prior`. A fresh event wins for its ex-date; any older ex-date the window did not
    re-fetch is carried forward from prior. Both are {sym: [{"ex":.., "ratio":.., ..}]}.
    Deterministic and network-free -> unit-testable."""
    merged = {}
    for sym in set(fresh) | set(prior):
        byex = {a["ex"]: a for a in prior.get(sym, [])}
        for a in fresh.get(sym, []):
            byex[a["ex"]] = a                      # fresh wins per ex-date
        merged[sym] = [byex[ex] for ex in sorted(byex)]
    return {sym: evs for sym, evs in sorted(merged.items())}
_MON = {m: i for i, m in enumerate(
    ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], 1)}


def _iso(ex):
    """'05-Jan-2024' -> '2024-01-05'."""
    m = re.match(r"(\d{1,2})-([A-Za-z]{3})-(\d{4})", (ex or "").strip())
    if not m:
        return None
    return f"{m.group(3)}-{_MON.get(m.group(2).title(), 0):02d}-{int(m.group(1)):02d}"


def _ratio(subject):
    """Price multiplier for a split / bonus / consolidation, else None (dividends, rights,
    AGMs … return None and are skipped)."""
    S = (subject or "").lower()
    # Face-value split / sub-division / consolidation: "From Rs X To Re/Rs Y" -> new/old.
    if any(k in S for k in ("split", "sub-div", "sub div", "consolidat", "face value")):
        m = re.search(r"from\s+rs?e?\.?\s*([\d.]+).*?to\s+rs?e?\.?\s*([\d.]+)", S)
        if m:
            old, new = float(m.group(1)), float(m.group(2))
            if old > 0 and new > 0:
                return round(new / old, 6)
    # Bonus a:b (a free per b held) -> shares ×(a+b)/b, price ×b/(a+b).
    # NSE says "Bonus 1:1"; BSE says "Bonus issue 15:10" · allow words between.
    m = re.search(r"bonus\b[^\d]*(\d+)\s*:\s*(\d+)", S)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if a + b > 0:
            return round(b / (a + b), 6)
    return None


def _merge_subject(existing, new):
    """Deterministic combined label when two actions share an ex-date (e.g. a same-day
    bonus + split, whose multipliers get multiplied). Sorted-unique join so the output is
    stable regardless of the order the feed returned the two rows in."""
    parts = set()
    for s in (existing, new):
        s = (s or "").strip()
        if s:
            parts.update(p.strip() for p in s.split(" + ") if p.strip())
    return " + ".join(sorted(parts))


def _iso_bse(ex):
    """BSE DefaultData ex-date '09 Mar 2026' -> '2026-03-09'."""
    m = re.match(r"(\d{1,2})\s+([A-Za-z]{3})\s+(\d{4})", (ex or "").strip())
    if not m:
        return None
    return f"{m.group(3)}-{_MON.get(m.group(2).title(), 0):02d}-{int(m.group(1)):02d}"


def _fetch_scrip_zip(session):
    """The always-latest BSE scrip.zip (same file fetch_surveillance pulls) as a ZipFile,
    or None. Fetched ONCE and shared by the ISIN↔scrip map + the CORPACT gap-fill below."""
    import io
    import zipfile
    try:
        z = FS._get(session, "https://www.bseindia.com/downloads/Help/file/scrip.zip",
                    "https://www.bseindia.com/", b"PK")
        return zipfile.ZipFile(io.BytesIO(z)) if z else None
    except Exception:
        return None


def _isin_to_scrip(zf):
    """{ISIN -> BSE scrip code} (and its inverse) from BSE_EQ_SCRIP. ({}, {}) on failure."""
    try:
        name = next((n for n in zf.namelist() if "BSE_EQ_SCRIP" in n.upper()), None)
        if not name:
            return {}, {}
        lines = zf.read(name).decode("latin-1", "replace").splitlines()
        hdr = [h.strip().lower() for h in lines[0].split(",")]
        ci_code = next((i for i, h in enumerate(hdr) if h in ("fininstrmid", "scrip_cd", "scripcode")), 0)
        ci_isin = next((i for i, h in enumerate(hdr) if h == "isin"), None)
        i2s, s2i = {}, {}
        if ci_isin is None:
            return {}, {}
        for ln in lines[1:]:
            p = ln.split(",")
            if len(p) > max(ci_code, ci_isin):
                iso = p[ci_isin].strip().upper()
                code = p[ci_code].strip()
                if iso and code.isdigit():
                    i2s[iso] = code
                    s2i[code] = iso
        return i2s, s2i
    except Exception:
        return {}, {}


def _corpact_ratio(purpose):
    """Price multiplier from a CORPACT purpose code · ONLY the unambiguous pure-bonus form
    'BN-AAAABBBB' (bonus AAAA:BBBB, a new per b held -> price ×b/(a+b)). Anything else (bare
    SS with no ratio, ET, or an SS+BN combo whose split ratio CORPACT omits) -> None, so the
    caller falls back to BSE DefaultData's text ratio."""
    p = (purpose or "").strip().upper()
    if "SS" in p or "ET" in p:          # combined / split / other -> not decodable here
        return None
    m = re.fullmatch(r"BN-(\d{4})(\d{4})", p)
    if m:
        a, b = int(m.group(1)), int(m.group(2))
        if a + b > 0:
            return round(b / (a + b), 6)
    return None


def _corpact_rows(zf):
    """CORPACT split/bonus rows -> [(scrip, iso_date, purpose)]. Date is the ex-date if
    present else the record date; both map to the observed cliff within a day or two."""
    try:
        name = next((n for n in zf.namelist() if "CORPACT" in n.upper()), None)
        if not name:
            return []
        out = []
        for ln in zf.read(name).decode("latin-1", "replace").splitlines()[1:]:
            p = ln.split("|")
            if len(p) < 7:
                continue
            purpose, rec, ex = p[3].strip(), p[2].strip(), p[4].strip()
            if not re.match(r"(SS|BN)\b", purpose):
                continue
            dt = ex if re.match(r"\d{4}-\d{2}-\d{2}", ex) else rec
            if re.match(r"\d{4}-\d{2}-\d{2}", dt):
                out.append((p[0].strip(), dt, purpose))
        return out
    except Exception:
        return []


def _screener_isin_to_sym():
    """{ISIN -> chartable symbol} for the WHOLE universe (not just BSE-only), so the CORPACT
    gap-fill can reach dual-listed names whose corp action NSE's feed missed."""
    for cand in (os.path.join(ROOT, "compressed_data", "screener_data.json"),
                 os.path.join(V4, "compressed_data", "screener_data.json")):
        if os.path.exists(cand):
            try:
                rows = (json.load(open(cand, encoding="utf-8")).get("all_stocks") or [])
            except Exception:
                continue
            out = {}
            for r in rows:
                iso = (r.get("isin") or "").upper()
                sym = (r.get("symbol") or "").upper()
                if iso and sym:
                    out.setdefault(iso, sym)
            return out
    return {}


def _days_apart(a, b):
    from datetime import date as D
    try:
        return abs((D.fromisoformat(a) - D.fromisoformat(b)).days)
    except Exception:
        return 9999


def _bse_only_symbols():
    """BSE-EXCLUSIVE stocks (a BSE row but NO NSE row for that ISIN) from the pipeline's
    screener_data.json -> [(symbol, isin)]. These are the ONLY stocks whose /stock chart
    uses BSE closes, so the NSE-symbol calendar can never cover them. Empty on failure."""
    for cand in (os.path.join(ROOT, "compressed_data", "screener_data.json"),
                 os.path.join(V4, "compressed_data", "screener_data.json")):
        if os.path.exists(cand):
            try:
                d = json.load(open(cand, encoding="utf-8"))
            except Exception:
                continue
            rows = d.get("all_stocks") or d.get("stocks") or []
            by_isin = {}
            for r in rows:
                by_isin.setdefault(r.get("isin"), {})[r.get("exchange")] = r
            out = []
            for iso, ex in by_isin.items():
                if iso and "BSE" in ex and "NSE" not in ex:
                    sym = (ex["BSE"].get("symbol") or "").strip().upper()
                    if sym:
                        out.append((sym, iso))
            return out
    return []


def _bse_augment(actions, session, isin2code, prior=None, incremental=False):
    """Fill split/bonus ratios for BSE-EXCLUSIVE stocks from BSE's per-scrip DefaultData
    corp-action feed (clean ex-date + ratio text, same '(From Rs X To Rs Y)'/'Bonus a:b'
    grammar as NSE). Only ADDS symbols the NSE calendar doesn't already carry (a dual-listed
    stock uses NSE closes, so NSE wins). Returns the count of BSE symbols added.

    Incremental: a BSE-exclusive split is immutable once recorded, so any symbol already in
    the committed file is SKIPPED (no per-scrip fetch) and carried forward by _carry_forward;
    only genuinely-new BSE-exclusive symbols are fetched. The weekly --full re-fetches all."""
    bse_only = _bse_only_symbols()
    if not bse_only or not isin2code:
        return 0
    # Committed BSE-exclusive entries, so a transient BSE-API outage on this runner can't
    # DROP them: a split doesn't un-happen, so we carry any prior entry forward when the
    # fresh fetch doesn't reproduce it (sticky, like the file's overall fail-open contract).
    if prior is None:
        prior = _load_prior_actions()
    ref = "https://www.bseindia.com/corporates/corporate_act.aspx"
    added = 0
    for sym, isin in bse_only:
        if sym in actions:            # NSE calendar already covers this symbol
            continue
        if incremental and sym in prior:   # immutable BSE-exclusive history -> carry-forward supplies it
            continue
        code = isin2code.get((isin or "").upper())
        if not code:
            continue
        url = ("https://api.bseindia.com/BseIndiaAPI/api/DefaultData/w"
               f"?ddlcategorys=E&ddlperiod=&scripcode={code}")
        b = FS._get(_bse_api_session(session), url, ref)
        byex = {}
        if b:
            try:
                rows = json.loads(b)
            except ValueError:
                rows = []
            for r in rows if isinstance(rows, list) else []:
                rt = _ratio(r.get("Purpose"))
                iso = _iso_bse(r.get("Ex_date"))
                if rt is None or not iso:
                    continue
                if iso in byex:                   # same-day split + bonus -> multiply
                    byex[iso]["ratio"] = round(byex[iso]["ratio"] * rt, 6)
                    byex[iso]["subject"] = _merge_subject(byex[iso]["subject"], r.get("Purpose"))
                else:
                    byex[iso] = {"ratio": rt, "subject": (r.get("Purpose") or "").strip()}
            time.sleep(0.25)
        if byex:
            actions[sym] = byex
            added += 1
        elif prior.get(sym):                      # fetch failed/empty -> keep prior entry
            actions[sym] = {a["ex"]: {k: v for k, v in a.items() if k != "ex"}
                            for a in prior[sym]}
            added += 1
    return added


def _corpact_fill(actions, session, zf, scrip2isin, isin2sym, prior=None, incremental=False):
    """Close the DUAL-LISTED gap adversarially found via BSE CORPACT: a stock listed on NSE
    *now* but whose split/bonus happened while it was BSE-listed is absent from NSE's feed
    AND skipped by _bse_augment (not BSE-exclusive), yet its NSE close series spans the cliff
    (VIRINCHI's 1:1 bonus, MUFIN's 2:1…). CORPACT (already in scrip.zip) lists every BSE
    split/bonus DATE; for any that maps to a chartable symbol and isn't already covered by the
    calendar (±6d), fill the ratio · from CORPACT's own 'BN-AAAABBBB' bonus code, else a
    targeted DefaultData lookup for that one scrip. Returns the count of gap dates filled."""
    rows = _corpact_rows(zf)
    if not rows or not scrip2isin or not isin2sym:
        return 0
    START_ISO = START.isoformat()
    ref = "https://www.bseindia.com/corporates/corporate_act.aspx"
    dd_cache = {}
    filled = 0
    for scrip, dt, purpose in rows:
        if dt < START_ISO:
            continue
        iso = scrip2isin.get(scrip)
        sym = isin2sym.get(iso) if iso else None
        if not sym:
            continue
        if any(_days_apart(dt, ex) <= 6 for ex in actions.get(sym, {})):
            continue                              # already covered (NSE or BSE-exclusive)
        if incremental and prior and any(_days_apart(dt, a["ex"]) <= 6 for a in prior.get(sym, [])):
            continue                              # already in the committed file -> carry-forward keeps it
        ratio = _corpact_ratio(purpose)
        subject = purpose
        if ratio is None:                         # bare SS / combo -> DefaultData text ratio
            if scrip not in dd_cache:
                b = FS._get(_bse_api_session(session), "https://api.bseindia.com/BseIndiaAPI/api/DefaultData/w"
                            f"?ddlcategorys=E&ddlperiod=&scripcode={scrip}", ref)
                try:
                    dd_cache[scrip] = json.loads(b) if b else []
                except ValueError:
                    dd_cache[scrip] = []
                time.sleep(0.25)
            for r in dd_cache[scrip] if isinstance(dd_cache[scrip], list) else []:
                diso = _iso_bse(r.get("Ex_date"))
                if diso and _days_apart(dt, diso) <= 4:
                    rt = _ratio(r.get("Purpose"))
                    if rt is not None:
                        ratio, subject, dt = rt, (r.get("Purpose") or "").strip(), diso
                        break
        if ratio is None:
            continue
        slot = actions.setdefault(sym, {})
        if dt in slot:
            slot[dt]["ratio"] = round(slot[dt]["ratio"] * ratio, 6)
            slot[dt]["subject"] = _merge_subject(slot[dt]["subject"], subject)
        else:
            slot[dt] = {"ratio": ratio, "subject": subject}
        filled += 1
    return filled


def build(generated="", full=False):
    s = FS._session()
    FS._get(s, "https://www.nseindia.com/", "https://www.nseindia.com/")
    today = datetime.date.today()
    ref = "https://www.nseindia.com/companies-listing/corporate-filings-actions"

    # Incremental (default): re-fetch only the recent window; a past split never
    # changes, so its entry is carried forward from the committed file. --full (or a
    # missing prior file) re-parses all of 2017->today.
    prior = {} if full else _load_prior_actions()
    incremental = bool(prior) and not full

    actions = {}          # symbol -> {ex_iso: {ratio, subject}}  (dedup by ex date)
    d = max(START, today - datetime.timedelta(days=INCREMENTAL_DAYS)) if incremental else START
    chunks = fetched = 0
    while d <= today:
        end = min(d + datetime.timedelta(days=CHUNK_DAYS - 1), today)
        url = ("https://www.nseindia.com/api/corporates-corporateActions?index=equities"
               f"&from_date={d.strftime('%d-%m-%Y')}&to_date={end.strftime('%d-%m-%Y')}")
        chunks += 1
        b = FS._get(s, url, ref)
        if b:
            try:
                rows = json.loads(b)
                rows = rows if isinstance(rows, list) else rows.get("data") or []
                fetched += 1
                for r in rows:
                    rt = _ratio(r.get("subject"))
                    iso = _iso(r.get("exDate") or r.get("ex_date"))
                    sym = (r.get("symbol") or "").strip().upper()
                    if rt is None or not iso or not sym:
                        continue
                    cur = actions.setdefault(sym, {}).get(iso)
                    # same-day split + bonus -> multiply the two multipliers.
                    if cur:
                        cur["ratio"] = round(cur["ratio"] * rt, 6)
                        cur["subject"] = _merge_subject(cur["subject"], r.get("subject"))
                    else:
                        actions.setdefault(sym, {})[iso] = {"ratio": rt, "subject": (r.get("subject") or "").strip()}
            except ValueError:
                pass
        d = end + datetime.timedelta(days=1)
        if b:
            time.sleep(0.3)

    if fetched == 0:
        raise RuntimeError("NSE corporate-actions fetch returned nothing (blocked?)")

    # BSE augmentation (the scrip.zip is fetched ONCE, shared by both passes). Best-effort —
    # never fails the NSE build.
    #  1) BSE-EXCLUSIVE stocks (no NSE listing): the NSE symbol calendar can't cover them, and
    #     their /stock chart uses BSE closes · fill from BSE's per-scrip DefaultData feed.
    #  2) CORPACT gap-fill: a dual-listed name whose split/bonus predates its NSE listing is in
    #     neither the NSE feed nor pass 1, yet its NSE close series spans the cliff (VIRINCHI,
    #     MUFIN…). CORPACT lists every BSE split/bonus date; fill any uncovered one.
    bse_added = corpact_filled = 0
    try:
        zf = _fetch_scrip_zip(s)
        isin2scrip, scrip2isin = _isin_to_scrip(zf) if zf else ({}, {})
        bse_added = _bse_augment(actions, s, isin2scrip, prior=prior, incremental=incremental)
        if zf:
            corpact_filled = _corpact_fill(actions, s, zf, scrip2isin, _screener_isin_to_sym(),
                                           prior=prior, incremental=incremental)
    except Exception:
        pass

    out = {sym: [{"ex": ex, **v} for ex, v in sorted(byex.items())]
           for sym, byex in sorted(actions.items())}

    # Incremental: overlay the freshly-fetched recent window onto the committed
    # history. A freshly-built event wins for its ex-date; any older ex-date the
    # incremental window did not re-fetch is carried forward from the prior file.
    # (The recent window is rebuilt from empty, so the same-day split+bonus ratio
    #  multiply above stays correct -- prior is only ever a gap-filler here.)
    if incremental:
        out = _carry_forward(out, prior)
    else:
        out = {sym: evs for sym, evs in sorted(out.items())}
    return {
        "_mode": "incremental" if incremental else "full",
        "_source": ("Authoritative split/bonus calendar. NSE-listed stocks come from NSE's "
                    "corporates-corporateActions BULK feed (2017→now, ~90-day chunks); BSE-EXCLUSIVE "
                    "stocks (no NSE listing, whose chart uses BSE closes) come from BSE's per-scrip "
                    "DefaultData feed; a CORPACT gap-fill adds any dual-listed split/bonus that "
                    "predates the stock's NSE listing (absent from NSE's feed). Ratio parsed from the "
                    "text ('From Rs10 To Re1' → 0.1; 'Bonus 1:1' → 0.5) or CORPACT's BN-AAAABBBB code. "
                    "The /stock chart back-adjusts the raw close by these · a big move NOT listed here "
                    "(e.g. an F&O stock with no price band) is left alone. Rights issues / demergers / "
                    "ratio-less consolidations are omitted (adjustment needs the missing ratio)."),
        "bse_exclusive": bse_added,
        "corpact_filled": corpact_filled,
        "_generated": generated or datetime.date.today().isoformat(),
        "chunks": chunks,
        "count": len(out),
        "events": sum(len(v) for v in out.values()),
        "actions": out,
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--generated", default="")
    ap.add_argument("--full", action="store_true",
                    help="re-fetch all of 2017->today (default: incremental, only the "
                         "recent window merged onto the committed file)")
    args = ap.parse_args()
    data = build(generated=args.generated, full=args.full)
    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(data, fh, ensure_ascii=False, separators=(",", ":"))
    print(f"corp_actions.json [{data['_mode']}]: {data['count']} stocks, {data['events']} split/bonus events "
          f"({data['chunks']} NSE chunks, {data.get('bse_exclusive', 0)} BSE-exclusive, "
          f"{data.get('corpact_filled', 0)} CORPACT gap-filled) -> {args.out}")
    for sym in ("NESTLEIND", "ADANIPOWER", "TATASTEEL", "RELIANCE", "TRENT",
                "VIRINCHI", "MUFIN", "GYFTR"):
        if sym in data["actions"]:
            print(f"  {sym}: {[(a['ex'], a['ratio']) for a in data['actions'][sym]]}")


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
    main()
